#ifndef NUMEROS_H_INCLUDED
#define NUMEROS_H_INCLUDED

    int numeros(char data[]);

#endif // NUMEROS_H_INCLUDED

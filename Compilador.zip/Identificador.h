#ifndef IDENTIFICADOR_H_INCLUDED
#define IDENTIFICADOR_H_INCLUDED

    bool identidacadorIdentificador(char data[]);

/*Agregar el metodo de creacion del token para su inserccion*/
#endif // IDENTIFICADOR_H_INCLUDED

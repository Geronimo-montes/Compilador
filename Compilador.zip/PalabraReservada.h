#ifndef PALABRARESERVADA_H_INCLUDED
#define PALABRARESERVADA_H_INCLUDED

    bool identidacadorPalRes(char data[]);

#endif // PALABRARESERVADA_H_INCLUDED
